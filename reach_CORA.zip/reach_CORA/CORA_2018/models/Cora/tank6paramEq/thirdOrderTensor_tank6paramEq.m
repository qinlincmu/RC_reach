function Tf = thirdOrderTensor_tank6paramEq(x,u,p)



 r = [(9*2^(1/2)*109^(1/2)*p(1))/(80*x(1)^(5/2))];



 C = cell(6,1);



 parfor i = 1:6



 switch i


 case 1 


 C{i}{1} = interval(sparse(7,7),sparse(7,7));

C{i}{1}(1,1) = -r(1);


 C{i}{2} = interval(sparse(7,7),sparse(7,7));



 C{i}{3} = interval(sparse(7,7),sparse(7,7));



 C{i}{4} = interval(sparse(7,7),sparse(7,7));



 C{i}{5} = interval(sparse(7,7),sparse(7,7));



 C{i}{6} = interval(sparse(7,7),sparse(7,7));



 C{i}{7} = interval(sparse(7,7),sparse(7,7));


 case 2 


 C{i}{1} = interval(sparse(7,7),sparse(7,7));

C{i}{1}(1,1) = r(1);


 C{i}{2} = interval(sparse(7,7),sparse(7,7));

C{i}{2}(2,2) = -(9*2^(1/2)*109^(1/2)*p(1))/(80*x(2)^(5/2));


 C{i}{3} = interval(sparse(7,7),sparse(7,7));



 C{i}{4} = interval(sparse(7,7),sparse(7,7));



 C{i}{5} = interval(sparse(7,7),sparse(7,7));



 C{i}{6} = interval(sparse(7,7),sparse(7,7));



 C{i}{7} = interval(sparse(7,7),sparse(7,7));


 case 3 


 C{i}{1} = interval(sparse(7,7),sparse(7,7));



 C{i}{2} = interval(sparse(7,7),sparse(7,7));

C{i}{2}(2,2) = (9*2^(1/2)*109^(1/2)*p(1))/(80*x(2)^(5/2));


 C{i}{3} = interval(sparse(7,7),sparse(7,7));

C{i}{3}(3,3) = -(9*2^(1/2)*109^(1/2)*p(1))/(80*x(3)^(5/2));


 C{i}{4} = interval(sparse(7,7),sparse(7,7));



 C{i}{5} = interval(sparse(7,7),sparse(7,7));



 C{i}{6} = interval(sparse(7,7),sparse(7,7));



 C{i}{7} = interval(sparse(7,7),sparse(7,7));


 case 4 


 C{i}{1} = interval(sparse(7,7),sparse(7,7));



 C{i}{2} = interval(sparse(7,7),sparse(7,7));



 C{i}{3} = interval(sparse(7,7),sparse(7,7));

C{i}{3}(3,3) = (9*2^(1/2)*109^(1/2)*p(1))/(80*x(3)^(5/2));


 C{i}{4} = interval(sparse(7,7),sparse(7,7));

C{i}{4}(4,4) = -(9*2^(1/2)*109^(1/2)*p(1))/(80*x(4)^(5/2));


 C{i}{5} = interval(sparse(7,7),sparse(7,7));



 C{i}{6} = interval(sparse(7,7),sparse(7,7));



 C{i}{7} = interval(sparse(7,7),sparse(7,7));


 case 5 


 C{i}{1} = interval(sparse(7,7),sparse(7,7));



 C{i}{2} = interval(sparse(7,7),sparse(7,7));



 C{i}{3} = interval(sparse(7,7),sparse(7,7));



 C{i}{4} = interval(sparse(7,7),sparse(7,7));

C{i}{4}(4,4) = (9*2^(1/2)*109^(1/2)*p(1))/(80*x(4)^(5/2));


 C{i}{5} = interval(sparse(7,7),sparse(7,7));

C{i}{5}(5,5) = -(9*2^(1/2)*109^(1/2)*p(1))/(80*x(5)^(5/2));


 C{i}{6} = interval(sparse(7,7),sparse(7,7));



 C{i}{7} = interval(sparse(7,7),sparse(7,7));


 case 6 


 C{i}{1} = interval(sparse(7,7),sparse(7,7));



 C{i}{2} = interval(sparse(7,7),sparse(7,7));



 C{i}{3} = interval(sparse(7,7),sparse(7,7));



 C{i}{4} = interval(sparse(7,7),sparse(7,7));



 C{i}{5} = interval(sparse(7,7),sparse(7,7));

C{i}{5}(5,5) = (9*2^(1/2)*109^(1/2)*p(1))/(80*x(5)^(5/2));


 C{i}{6} = interval(sparse(7,7),sparse(7,7));

C{i}{6}(6,6) = -(9*2^(1/2)*109^(1/2)*p(1))/(80*x(6)^(5/2));


 C{i}{7} = interval(sparse(7,7),sparse(7,7));



 end
end

for i=1:6
for j=1:7
Tf{i,j} = C{i}{j};
end
end
