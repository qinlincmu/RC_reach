test_taylm_asin_acos_atan();
test_taylm_division();
test_taylm_exp();
test_taylm_log();
test_taylm_matrix();
test_taylm_plus_minus_times();
test_taylm_sin_cos_sinh_cosh();
test_taylm_sqrt();
test_taylm_optimizer();
test_taylm_reexpand();
test_globalOptimizer();
disp('All tests are passed')