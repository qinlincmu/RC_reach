function dx = RCeq_kinematic(t,x,u)
% for a given acceleration and yaw rate
%
% Syntax:  
%    f = RCeq1(t,x,u)
%
% Inputs:
%    f
%
% Outputs:
%
% Example: 
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: ---

%------------- BEGIN CODE --------------

%load parameters
g = 9.81; %[m/s^2]

%get model paramters
%p = SRXparameters();

%create equivalent bicycle parameters
%mu = p.tire.p_dy1;
%mu = 1.0; %<-- hard coded
vehicle.L = 0.257;          % wheelbase (m)
vehicle.L_f = 0.115;        % CoG to front axle (m)
vehicle.L_r = 0.142;        % CoG to rear axle (m)
vehicle.tw = 0.165;         % trackwidth (m)

vehicle.wheel_dia = 0.0323; % wheel diameter (m)
vehicle.wheel_w = 0.025;    % wheel width (m)

vehicle.m = 2.596;          % mass (kg)
%vehicle.g = 9.81;           % gravity const (m/s^2)

vehicle.load_f = vehicle.m*g*vehicle.L_r/vehicle.L;
vehicle.load_r = vehicle.m*g*vehicle.L_f/vehicle.L;

vehicle.C_x = 103.94;       % longitudinal stiffness (N)
vehicle.C_alpha = 56.4;     % cornering stiffness (N)
vehicle.I_z = 0.0558;       % rotation inertia (kgm^2)
vehicle.mu = 1.37;          % friction coefficient
vehicle.mu_slide = 1.96;    % sliding friction coefficient
vehicle.h = 0.5;%% not sure what is it

vehicle.C_F = 55.2284; %%%get it from https://docs.google.com/document/d/1KmUQhDiH_9QoF40nhYn_VT8QSlQbrsnRwSVV7mkHze0/edit#
vehicle.C_R = 55.2284;

%states
%x1 = x position
%x2 = y position
%x3 = psi heading angle?
%x4 = v_x x-position in a global coordinate system
%x5 = v_y y-position in a global coordinate system
%x6 = psi_dot heading angle speed?

%u1 = x_d
%u2 = y_d
%u3 = psi_d
%u4 = delta_psi_d

k1 = 1.2;
k2 = 1;
k3 = 1;
k4 = 1;
k5 = 1.2;
k6 = 1;

%system dynamics

pos_x = x(1);
pos_y = x(2);
psi = x(3);
v = x(4);
beta = x(5);
delta_f = x(6);

x_d = u(1);
y_d = u(2);
v_d = u(3);
psi_d = u(4);
psi_dot_d = u(5);

beta = atan(vehicle.L_r * tan(delta_f)/vehicle.L);
psi_dot = v * sin(beta)/vehicle.L_r;

%epsilon_x = k1 * (cos(u(3))*(u(1)-x4)-sin(u(3))*(u(2)-x2)) + k2 * (u3 - x3) + k3 * (u4 - x6) - k4 *
%epsilon_y = -sin(u(3))*(u(1)-x4)+cos(u(3))*(u(2)-x2);
delta_dot = k1 * (cos(psi_d) * (y_d - pos_y) -  sin(psi_d) * (x_d - pos_x)) + k2 * (psi_d - psi) + k3 * (psi_dot_d - psi_dot) - k4 * delta_f;
v_dot = k5 * (cos(psi_d) * (x_d - pos_x) + sin(psi_d) * (y_d - pos_y)) + k6 * (v_d - v);

    dx(1,1) = v * cos(psi+beta); %x_dot
    dx(2,1) = v * sin(psi+beta); %y_dot
    dx(3,1) = psi_dot; %psi_dot
    dx(4,1) = v_dot; %v_dot
    dx(5,1) = 0; %beta
    dx(6,1) = delta_dot; %delta_dot

%------------- END OF CODE --------------
