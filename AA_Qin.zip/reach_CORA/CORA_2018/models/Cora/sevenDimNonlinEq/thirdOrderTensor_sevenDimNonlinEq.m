function Tf = thirdOrderTensor_sevenDimNonlinEq(x,u)



 Tf{1,1} = interval(sparse(8,8),sparse(8,8));



 Tf{1,2} = interval(sparse(8,8),sparse(8,8));



 Tf{1,3} = interval(sparse(8,8),sparse(8,8));



 Tf{1,4} = interval(sparse(8,8),sparse(8,8));



 Tf{1,5} = interval(sparse(8,8),sparse(8,8));



 Tf{1,6} = interval(sparse(8,8),sparse(8,8));



 Tf{1,7} = interval(sparse(8,8),sparse(8,8));



 Tf{1,8} = interval(sparse(8,8),sparse(8,8));



 Tf{2,1} = interval(sparse(8,8),sparse(8,8));



 Tf{2,2} = interval(sparse(8,8),sparse(8,8));



 Tf{2,3} = interval(sparse(8,8),sparse(8,8));



 Tf{2,4} = interval(sparse(8,8),sparse(8,8));



 Tf{2,5} = interval(sparse(8,8),sparse(8,8));



 Tf{2,6} = interval(sparse(8,8),sparse(8,8));



 Tf{2,7} = interval(sparse(8,8),sparse(8,8));



 Tf{2,8} = interval(sparse(8,8),sparse(8,8));



 Tf{3,1} = interval(sparse(8,8),sparse(8,8));



 Tf{3,2} = interval(sparse(8,8),sparse(8,8));



 Tf{3,3} = interval(sparse(8,8),sparse(8,8));



 Tf{3,4} = interval(sparse(8,8),sparse(8,8));



 Tf{3,5} = interval(sparse(8,8),sparse(8,8));



 Tf{3,6} = interval(sparse(8,8),sparse(8,8));



 Tf{3,7} = interval(sparse(8,8),sparse(8,8));



 Tf{3,8} = interval(sparse(8,8),sparse(8,8));



 Tf{4,1} = interval(sparse(8,8),sparse(8,8));



 Tf{4,2} = interval(sparse(8,8),sparse(8,8));



 Tf{4,3} = interval(sparse(8,8),sparse(8,8));



 Tf{4,4} = interval(sparse(8,8),sparse(8,8));



 Tf{4,5} = interval(sparse(8,8),sparse(8,8));



 Tf{4,6} = interval(sparse(8,8),sparse(8,8));



 Tf{4,7} = interval(sparse(8,8),sparse(8,8));



 Tf{4,8} = interval(sparse(8,8),sparse(8,8));



 Tf{5,1} = interval(sparse(8,8),sparse(8,8));



 Tf{5,2} = interval(sparse(8,8),sparse(8,8));



 Tf{5,3} = interval(sparse(8,8),sparse(8,8));



 Tf{5,4} = interval(sparse(8,8),sparse(8,8));



 Tf{5,5} = interval(sparse(8,8),sparse(8,8));



 Tf{5,6} = interval(sparse(8,8),sparse(8,8));



 Tf{5,7} = interval(sparse(8,8),sparse(8,8));



 Tf{5,8} = interval(sparse(8,8),sparse(8,8));



 Tf{6,1} = interval(sparse(8,8),sparse(8,8));



 Tf{6,2} = interval(sparse(8,8),sparse(8,8));



 Tf{6,3} = interval(sparse(8,8),sparse(8,8));



 Tf{6,4} = interval(sparse(8,8),sparse(8,8));



 Tf{6,5} = interval(sparse(8,8),sparse(8,8));



 Tf{6,6} = interval(sparse(8,8),sparse(8,8));



 Tf{6,7} = interval(sparse(8,8),sparse(8,8));



 Tf{6,8} = interval(sparse(8,8),sparse(8,8));



 Tf{7,1} = interval(sparse(8,8),sparse(8,8));



 Tf{7,2} = interval(sparse(8,8),sparse(8,8));



 Tf{7,3} = interval(sparse(8,8),sparse(8,8));



 Tf{7,4} = interval(sparse(8,8),sparse(8,8));



 Tf{7,5} = interval(sparse(8,8),sparse(8,8));



 Tf{7,6} = interval(sparse(8,8),sparse(8,8));



 Tf{7,7} = interval(sparse(8,8),sparse(8,8));



 Tf{7,8} = interval(sparse(8,8),sparse(8,8));

